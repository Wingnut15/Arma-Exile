# Sarge AI Fork
Dango

https://www.hod-servers.com/forum

# SARGE AI
Thanks to SARGE for executing a great idea for Arma survival style servers.

https://github.com/Swiss-Sarge

# UPSMON
I (Cool=Azroul13) continue to work on the UPSMON script, created by Monsada for Arma2, improved by Rafalsky, Nordin and Shay_Gman and ported to Arma 3 by Ollem.

Many thanks to:
- Kronzky who create the UPS script which is the base of UPSMON
- Monsada who's the one that create this master piece.
- Rafalsky who made several improvements to the script.
- Beerkan,Ollem,Shaygman who made improvements and port the script to ArmaIII
- Mando for his "mando_check_los" script.
- Carl Gustav for his "sun_angle" script.
- Das Attornay for helping me with the fortify module.
- Shuko for his "shkpos" that help me a lot...
- All Armaholic 's staff ...
- Molina for all his advice...
- Grumpy old man for taking time to test this new version of UPSMON and for all his support.
- Gienkov,Kord,TMP95,RedArmy and many others who test all pieces of the script ...
