### Step 1
Package and/or place the sarge PBO inside the @servermod\addons folder.

### Step 2
Place the files that are in ModName.MapName or add the init.sqf line to your exisitng init.sqf inside of your mission folder and repack.

### Step 3
Start the server and check your log to see if Sarge AI is loading properly.
