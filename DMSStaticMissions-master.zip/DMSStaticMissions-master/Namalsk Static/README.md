# DMS Namalsk Static Missions
<b>Exile DMS Static Missions for Namalsk</b><br>

<b>This mission is untested for version 2.1</b><br>
M3 Editor file included<br>

*******************************************************
	Static missions for Namalsk.
	Created by [CiC]red_ned using templates by eraser1 
	19 years of CiC http://cic-gaming.co.uk
*******************************************************
	For Namalsk only.
	Running on DMS System
*******************************************************
You must have DMS installed<br>

*******************************************************
<b>v1.0</b> is hardcore only with no vehicle.<br>
<b>v2.1</b> is multi difficulties with chance of persistent vehicle (on some missions) and lots of editable functions.
*******************************************************

<b>Updated 27 March 2017</b><br>
Added cash in crates<br>
Tidied code<br>