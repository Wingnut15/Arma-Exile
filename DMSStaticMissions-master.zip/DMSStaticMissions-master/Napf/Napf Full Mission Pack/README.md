# 11 DMSStaticMissions
Exile DMS Napf Static Missions


*******************************************************
	11 Static missions for Napf.
	Credits to Pradatoru for some mapping
	Created by [CiC]red_ned using templates by eraser1 
	19 years of CiC http://cic-gaming.co.uk
*******************************************************
	Only run on Napf map
	Running on DMS System
*******************************************************
	Camp Audacity Mission
	Camp Bravery Mission
	Camp Courage Mission
	Camp Fortitude Mission
	Froburg Castle Mission
	Homburg Castle Mission
	Muttenz Church Mission
	Napf Castle Mission
	Occupied Island Mission
	Oil Island Mission
	Stranded Bandits Mission
	+4 Bridges & Map Markers for missions
*******************************************************
Military_Base_Mission.sqf is not completed but mapping etc is included and would be 12
