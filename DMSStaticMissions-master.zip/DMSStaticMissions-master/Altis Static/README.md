# DMS Static Missions
*******************************************************<BR>
	Static missions for Altis.<BR>
	Credits to Pradatoru for some mapping<BR>
	Created by [CiC]red_ned using templates by eraser1 <BR>
	19 years of CiC http://cic-gaming.co.uk<BR>
*******************************************************<BR>
	For Altis only.<BR>
	Running on DMS System<BR>
*******************************************************<BR>
You must have DMS installed<BR>

Some missions contain v1.0 and v2.0 zips with original hardcore only mode and pre v2.1 code<BR>
AI Island, Castle 183, Kore Factory and Storage Invasion come in both v1.0 and v2.0 at least<BR>
v1.0 = Hardcore only<BR>
v2.0 = Random difficulty selection<BR>
v2.1 = Random difficulty selection plus better layout for editing parameters and sliding %chance for vehicle persistence (if vehicle is in mission)<BR>