# DMS Altis Static Thelos Racetrack Mission BETA
<b>Exile DMS Static Missions for Altis</b><br>

<b>This mission is untested for some versions</b><br>
<b>Use at own risk and report any issues to Exile forums</b><br>
M3 Editor files included<br>

*******************************************************
	Static missions for Altis.
	Created by [CiC]red_ned using templates by eraser1 
	17 years of CiC http://cic-gaming.co.uk
	Thanks to jmayr2000 for helping debug and test.
*******************************************************
	For Altis only.
	Running on DMS System
*******************************************************
You must have DMS installed<br>

<b>New Thelos Racetrack mission (BETA)</b><br>
This version is currently untested<br>
It is over complicated on purpose to allow maximum configuration<br>
Please report issues on Exile forums<br>
M3 Editor files included<br>


*******************************************************
<b>thelosracetrack</b> is multi difficulties with chance of persistent vehicle with ground AI patrols and AI heli.
*******************************************************