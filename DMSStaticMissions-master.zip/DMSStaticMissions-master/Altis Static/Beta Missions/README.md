# DMS Altis Static Thelos Racetrack Mission BETA
<b>Exile DMS Static Missions for Altis</b><br>

<b>These missions are untested for some/all versions</b><br>
<b>Use at own risk and report any issues to Exile forums</b><br>
*******************************************************
	Static missions for Altis.
	Created by [CiC]red_ned using templates by eraser1 
	19 years of CiC http://cic-gaming.co.uk
	Thanks to jmayr2000 for helping debug and test.
*******************************************************
	For Altis only.
	Running on DMS System
*******************************************************
<b>You must have DMS installed</b><br>

<b>Beta selection of missions</b><br>
All missions in BETA are pre-testing or in developing states <br>
Code may not be complete to a finished shine <br>
Anything that isnt in a working state will be commented <br>

<b>1. New Thelos Racetrack mission (BETA)</b><br>
This version is currently untested<br>
Please report issues on Exile forums<br>
M3 Editor files included<br>
*******************************************************
<b>thelosracetrack</b> is multi difficulties with chance of persistent vehicle with ground AI patrols and AI heli.
*******************************************************
<b>Not recommended for live servers</b><br>
Please report any BETA mission issues or comments (especially if they are working) so i can add them to the live package<br>
*******************************************************