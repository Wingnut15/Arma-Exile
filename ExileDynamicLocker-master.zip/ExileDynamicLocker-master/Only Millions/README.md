# ExileDynamicLocker no "k"


# Installation
These files just replace the ones from the install to ignore "K" and just do million shortening<br>
Just overwrite the other ones with these<br>